import Cart1 from '../assets/cart1.png'
import Cart2 from '../assets/cart2.png'

export const CartList = [
    {
        title:"Women Girl Watch Silico",
        img: Cart1,
        size: "L",
        quantity: 1,
        price:250,
        seller:"Palatos Malesto",
        id:12

    },
    {
        title:"Fashionable Women Girl Watch Silicone ",
        img: Cart2,
        size: "S",
        quantity: 1,
        price:55,
        seller:"Voole Satusd",
        id:13

    },
]
